#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Test package.

Copyright (C) 2016 Canux CHENG.
All rights reserved.
Name: __init__.py
Author: Canux CHENG canuxcheng@gmail.com
Version: V1.0.0.0
Time: Sun 23 Oct 2016 10:10:29 AM EDT
"""
