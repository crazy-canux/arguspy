=============================
pyMonitoringPluginsingPlugins
=============================

pyMonitoringPluginsingPlugins is pure python code.

It's a API packge for monitoring plugins, like nagios or icinga.

`[awesome-monitoring] <https://github.com/crazy-canux/awesome-monitoring>`_.

--------------
How to install
--------------

Use pip to install:

    pip install pyMonitoringPluginsingPlugins

----------
How to use
----------

    import pyMonitoringPluginsingPlugins

--------------
How to extends
--------------

Check the TODO list, you can give test examples or documents.

Also you can pull request for your code.

-----
TODO
-----

1. snmp
2. http
3. pyMonitoringPlugins/docs build with sphinx
4. wmi_sh.py

============
Contribution
============

`[Contribution] <https://github.com/crazy-canux/pyMonitoringPlugins/blob/master/CONTRIBUTING.rst>`_

=======
Authors
=======

`[Authors] <https://github.com/crazy-canux/pyMonitoringPlugins/blob/master/AUTHORS.rst>`_

=======
License
=======

`[License] <https://github.com/crazy-canux/pyMonitoringPlugins/blob/master/LICENSE>`_


